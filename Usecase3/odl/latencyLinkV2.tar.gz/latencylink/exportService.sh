#bin/bash
#Copier .jar de service et de model dans le dossier plugins de ODL Base dans integration
source couleur.sh

echo "Script Start"

echo " In service"

cd service/
mvn clean install

if [ $? -eq 0 ] ;then

echo " Out Service"
cd ../

echo " Copy .jar"
cp service/target/latencylink-service-1.1-SNAPSHOT.jar ~/integration/distributions/base/target/distributions-base-0.2.0-SNAPSHOT-osgipackage/opendaylight/plugins/

else
echo ""
echo -e "${rougefonce}[ERROR]   BUILD FAILED   [ERROR]${neutre}"
echo ""
echo " Out Service"
cd ../
exit 1
fi

echo "Script End"
echo ""
echo -e  "${vertclair}[INFO]   SERVICE BUILD OK   [ÌNFO]${neutre}"
echo ""

exit
