package org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.latencies.link;
import java.util.Collections;
import java.util.Map;
import org.opendaylight.yangtools.yang.binding.DataObject;
import java.util.HashMap;
import org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.latencies.link.LatencyLinkKey;
import java.math.BigDecimal;
import org.opendaylight.yangtools.yang.binding.Augmentation;


/**
 * Class that builds {@link org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.latencies.link.LatencyLink} instances.
 * @see org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.latencies.link.LatencyLink
 */
public class LatencyLinkBuilder {

    private BigDecimal _value;
    private java.lang.Long _timeStamp;
    private LatencyLinkKey _key;

    private Map<java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.latencies.link.LatencyLink>>, Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.latencies.link.LatencyLink>> augmentation = new HashMap<>();

    public LatencyLinkBuilder() {
    } 

    public LatencyLinkBuilder(LatencyLink base) {
        if (base.getKey() == null) {
            this._key = new LatencyLinkKey(
                base.getTimeStamp()
            );
            this._timeStamp = base.getTimeStamp();
        } else {
            this._key = base.getKey();
            this._timeStamp = _key.getTimeStamp();
        }
        this._value = base.getValue();
        if (base instanceof LatencyLinkImpl) {
            LatencyLinkImpl _impl = (LatencyLinkImpl) base;
            this.augmentation = new HashMap<>(_impl.augmentation);
        }
    }


    public BigDecimal getValue() {
        return _value;
    }
    
    public java.lang.Long getTimeStamp() {
        return _timeStamp;
    }
    
    public LatencyLinkKey getKey() {
        return _key;
    }
    
    @SuppressWarnings("unchecked")
    public <E extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.latencies.link.LatencyLink>> E getAugmentation(java.lang.Class<E> augmentationType) {
        if (augmentationType == null) {
            throw new IllegalArgumentException("Augmentation Type reference cannot be NULL!");
        }
        return (E) augmentation.get(augmentationType);
    }

    public LatencyLinkBuilder setValue(BigDecimal value) {
        this._value = value;
        return this;
    }
    
    public LatencyLinkBuilder setTimeStamp(java.lang.Long value) {
        this._timeStamp = value;
        return this;
    }
    
    public LatencyLinkBuilder setKey(LatencyLinkKey value) {
        this._key = value;
        return this;
    }
    
    public LatencyLinkBuilder addAugmentation(java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.latencies.link.LatencyLink>> augmentationType, Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.latencies.link.LatencyLink> augmentation) {
        this.augmentation.put(augmentationType, augmentation);
        return this;
    }

    public LatencyLink build() {
        return new LatencyLinkImpl(this);
    }

    private static final class LatencyLinkImpl implements LatencyLink {

        public java.lang.Class<org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.latencies.link.LatencyLink> getImplementedInterface() {
            return org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.latencies.link.LatencyLink.class;
        }

        private final BigDecimal _value;
        private final java.lang.Long _timeStamp;
        private final LatencyLinkKey _key;

        private Map<java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.latencies.link.LatencyLink>>, Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.latencies.link.LatencyLink>> augmentation = new HashMap<>();

        private LatencyLinkImpl(LatencyLinkBuilder base) {
            if (base.getKey() == null) {
                this._key = new LatencyLinkKey(
                    base.getTimeStamp()
                );
                this._timeStamp = base.getTimeStamp();
            } else {
                this._key = base.getKey();
                this._timeStamp = _key.getTimeStamp();
            }
            this._value = base.getValue();
                switch (base.augmentation.size()) {
                case 0:
                    this.augmentation = Collections.emptyMap();
                    break;
                    case 1:
                        final Map.Entry<java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.latencies.link.LatencyLink>>, Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.latencies.link.LatencyLink>> e = base.augmentation.entrySet().iterator().next();
                        this.augmentation = Collections.<java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.latencies.link.LatencyLink>>, Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.latencies.link.LatencyLink>>singletonMap(e.getKey(), e.getValue());       
                    break;
                default :
                    this.augmentation = new HashMap<>(base.augmentation);
                }
        }

        @Override
        public BigDecimal getValue() {
            return _value;
        }
        
        @Override
        public java.lang.Long getTimeStamp() {
            return _timeStamp;
        }
        
        @Override
        public LatencyLinkKey getKey() {
            return _key;
        }
        
        @SuppressWarnings("unchecked")
        @Override
        public <E extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.latencies.link.LatencyLink>> E getAugmentation(java.lang.Class<E> augmentationType) {
            if (augmentationType == null) {
                throw new IllegalArgumentException("Augmentation Type reference cannot be NULL!");
            }
            return (E) augmentation.get(augmentationType);
        }

        @Override
        public int hashCode() {
            final int prime = 31;
            int result = 1;
            result = prime * result + ((_value == null) ? 0 : _value.hashCode());
            result = prime * result + ((_timeStamp == null) ? 0 : _timeStamp.hashCode());
            result = prime * result + ((_key == null) ? 0 : _key.hashCode());
            result = prime * result + ((augmentation == null) ? 0 : augmentation.hashCode());
            return result;
        }

        @Override
        public boolean equals(java.lang.Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof DataObject)) {
                return false;
            }
            if (!org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.latencies.link.LatencyLink.class.equals(((DataObject)obj).getImplementedInterface())) {
                return false;
            }
            org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.latencies.link.LatencyLink other = (org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.latencies.link.LatencyLink)obj;
            if (_value == null) {
                if (other.getValue() != null) {
                    return false;
                }
            } else if(!_value.equals(other.getValue())) {
                return false;
            }
            if (_timeStamp == null) {
                if (other.getTimeStamp() != null) {
                    return false;
                }
            } else if(!_timeStamp.equals(other.getTimeStamp())) {
                return false;
            }
            if (_key == null) {
                if (other.getKey() != null) {
                    return false;
                }
            } else if(!_key.equals(other.getKey())) {
                return false;
            }
            if (getClass() == obj.getClass()) {
                // Simple case: we are comparing against self
                LatencyLinkImpl otherImpl = (LatencyLinkImpl) obj;
                if (augmentation == null) {
                    if (otherImpl.augmentation != null) {
                        return false;
                    }
                } else if(!augmentation.equals(otherImpl.augmentation)) {
                    return false;
                }
            } else {
                // Hard case: compare our augments with presence there...
                for (Map.Entry<java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.latencies.link.LatencyLink>>, Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.latencies.link.LatencyLink>> e : augmentation.entrySet()) {
                    final Object oa = other.getAugmentation(e.getKey());
                    if (!e.getValue().equals(oa)) {
                        return false;
                    }
                }
                // .. and give the other one the chance to do the same
                if (!obj.equals(this)) {
                    return false;
                }
            }
            return true;
        }
        
        @Override
        public java.lang.String toString() {
            java.lang.StringBuilder builder = new java.lang.StringBuilder ("LatencyLink [");
            boolean first = true;
        
            if (_value != null) {
                if (first) {
                    first = false;
                } else {
                    builder.append(", ");
                }
                builder.append("_value=");
                builder.append(_value);
             }
            if (_timeStamp != null) {
                if (first) {
                    first = false;
                } else {
                    builder.append(", ");
                }
                builder.append("_timeStamp=");
                builder.append(_timeStamp);
             }
            if (_key != null) {
                if (first) {
                    first = false;
                } else {
                    builder.append(", ");
                }
                builder.append("_key=");
                builder.append(_key);
             }
            if (first) {
                first = false;
            } else {
                builder.append(", ");
            }
            builder.append("augmentation=");
            builder.append(augmentation.values());
            return builder.append(']').toString();
        }
    }

}
