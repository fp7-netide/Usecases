package org.opendaylight.yang.gen.v1.urn.opendaylight.latency._switch.model.rev140606;
import org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.LatenciesLink;
import org.opendaylight.yang.gen.v1.urn.tbd.params.xml.ns.yang.network.topology.rev131021.network.topology.topology.Node;
import org.opendaylight.yangtools.yang.binding.DataObject;
import org.opendaylight.yangtools.yang.binding.Augmentation;


public interface LatenciesSwitch
    extends
    DataObject,
    Augmentation<Node>,
    LatenciesLink
{





}

