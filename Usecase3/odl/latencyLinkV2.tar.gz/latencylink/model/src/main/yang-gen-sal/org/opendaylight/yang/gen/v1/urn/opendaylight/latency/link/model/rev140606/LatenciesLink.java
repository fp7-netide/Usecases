package org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606;
import org.opendaylight.yangtools.yang.common.QName;
import org.opendaylight.yangtools.yang.binding.DataObject;
import org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.latencies.link.LatencyLink;
import java.util.List;


/**
 * <p>This class represents the following YANG schema fragment defined in module <b>latency-link-model</b>
 * <br />(Source path: <i>META-INF/yang/latency-link-model.yang</i>):
 * <pre>
 * grouping latencies-link {
 *     list latency-link {
 *         key "timeStamp"
 *         leaf value {
 *             type decimal64;
 *         }
 *         leaf timeStamp {
 *             type int64;
 *         }
 *     }
 * }
 * </pre>
 * The schema path to identify an instance is
 * <i>latency-link-model/latencies-link</i>
 */
public interface LatenciesLink
    extends
    DataObject
{



    public static final QName QNAME = org.opendaylight.yangtools.yang.common.QName.create("urn:opendaylight:latency-link-model","2014-06-06","latencies-link");;

    List<LatencyLink> getLatencyLink();

}

