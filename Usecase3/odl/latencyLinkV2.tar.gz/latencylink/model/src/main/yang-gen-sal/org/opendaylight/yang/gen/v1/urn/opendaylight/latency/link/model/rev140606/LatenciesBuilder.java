package org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606;
import org.opendaylight.yangtools.yang.binding.DataObject;
import org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.latencies.link.LatencyLink;
import java.util.List;


/**
 * Class that builds {@link org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.Latencies} instances.
 * @see org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.Latencies
 */
public class LatenciesBuilder {

    private List<LatencyLink> _latencyLink;


    public LatenciesBuilder() {
    } 
    
    public LatenciesBuilder(org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.LatenciesLink arg) {
        this._latencyLink = arg.getLatencyLink();
    }

    public LatenciesBuilder(Latencies base) {
        this._latencyLink = base.getLatencyLink();
    }

    /**
     *Set fields from given grouping argument. Valid argument is instance of one of following types:
     * <ul>
     * <li>org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.LatenciesLink</li>
     * </ul>
     *
     * @param arg grouping object
     * @throws IllegalArgumentException if given argument is none of valid types
    */
    public void fieldsFrom(DataObject arg) {
        boolean isValidArg = false;
        if (arg instanceof org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.LatenciesLink) {
            this._latencyLink = ((org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.LatenciesLink)arg).getLatencyLink();
            isValidArg = true;
        }
        if (!isValidArg) {
            throw new IllegalArgumentException(
              "expected one of: [org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.LatenciesLink] \n" +
              "but was: " + arg
            );
        }
    }

    public List<LatencyLink> getLatencyLink() {
        return _latencyLink;
    }

    public LatenciesBuilder setLatencyLink(List<LatencyLink> value) {
        this._latencyLink = value;
        return this;
    }

    public Latencies build() {
        return new LatenciesImpl(this);
    }

    private static final class LatenciesImpl implements Latencies {

        public java.lang.Class<org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.Latencies> getImplementedInterface() {
            return org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.Latencies.class;
        }

        private final List<LatencyLink> _latencyLink;


        private LatenciesImpl(LatenciesBuilder base) {
            this._latencyLink = base.getLatencyLink();
        }

        @Override
        public List<LatencyLink> getLatencyLink() {
            return _latencyLink;
        }

        @Override
        public int hashCode() {
            final int prime = 31;
            int result = 1;
            result = prime * result + ((_latencyLink == null) ? 0 : _latencyLink.hashCode());
            return result;
        }

        @Override
        public boolean equals(java.lang.Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof DataObject)) {
                return false;
            }
            if (!org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.Latencies.class.equals(((DataObject)obj).getImplementedInterface())) {
                return false;
            }
            org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.Latencies other = (org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.Latencies)obj;
            if (_latencyLink == null) {
                if (other.getLatencyLink() != null) {
                    return false;
                }
            } else if(!_latencyLink.equals(other.getLatencyLink())) {
                return false;
            }
            return true;
        }
        
        @Override
        public java.lang.String toString() {
            java.lang.StringBuilder builder = new java.lang.StringBuilder ("Latencies [");
            boolean first = true;
        
            if (_latencyLink != null) {
                if (first) {
                    first = false;
                } else {
                    builder.append(", ");
                }
                builder.append("_latencyLink=");
                builder.append(_latencyLink);
             }
            return builder.append(']').toString();
        }
    }

}
