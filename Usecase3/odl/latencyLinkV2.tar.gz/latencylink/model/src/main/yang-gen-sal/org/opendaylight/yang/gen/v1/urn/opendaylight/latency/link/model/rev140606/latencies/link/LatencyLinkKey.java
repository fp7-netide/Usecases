package org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.latencies.link;
import org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.latencies.link.LatencyLink;
import org.opendaylight.yangtools.yang.binding.Identifier;


public class LatencyLinkKey
 implements Identifier<LatencyLink> {
    private static final long serialVersionUID = -5625959521036909499L; 
    final private java.lang.Long _timeStamp;
    
    public LatencyLinkKey(java.lang.Long _timeStamp) {
        this._timeStamp = _timeStamp;
    }
    
    /**
     * Creates a copy from Source Object.
     *
     * @param source Source object
     */
    public LatencyLinkKey(LatencyLinkKey source) {
        this._timeStamp = source._timeStamp;
    }


    public java.lang.Long getTimeStamp() {
        return _timeStamp;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((_timeStamp == null) ? 0 : _timeStamp.hashCode());
        return result;
    }

    @Override
    public boolean equals(java.lang.Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        LatencyLinkKey other = (LatencyLinkKey) obj;
        if (_timeStamp == null) {
            if (other._timeStamp != null) {
                return false;
            }
        } else if(!_timeStamp.equals(other._timeStamp)) {
            return false;
        }
        return true;
    }

    @Override
    public java.lang.String toString() {
        java.lang.StringBuilder builder = new java.lang.StringBuilder(org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.latencies.link.LatencyLinkKey.class.getSimpleName()).append(" [");
        boolean first = true;
    
        if (_timeStamp != null) {
            if (first) {
                first = false;
            } else {
                builder.append(", ");
            }
            builder.append("_timeStamp=");
            builder.append(_timeStamp);
         }
        return builder.append(']').toString();
    }



}
