package org.opendaylight.yang.gen.v1.urn.opendaylight.latency._switch.model.rev140606;

public final class $YangModelBindingProvider implements org.opendaylight.yangtools.yang.binding.YangModelBindingProvider {

    public org.opendaylight.yangtools.yang.binding.YangModuleInfo getModuleInfo() {
        return $YangModuleInfoImpl.getInstance();
    }
}
