package org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.latencies.link;
import org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.LatenciesLink;
import org.opendaylight.yangtools.yang.common.QName;
import org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.latencies.link.LatencyLinkKey;
import org.opendaylight.yangtools.yang.binding.ChildOf;
import org.opendaylight.yangtools.yang.binding.Identifiable;
import java.math.BigDecimal;
import org.opendaylight.yangtools.yang.binding.Augmentable;


/**
 * <p>This class represents the following YANG schema fragment defined in module <b>latency-link-model</b>
 * <br />(Source path: <i>META-INF/yang/latency-link-model.yang</i>):
 * <pre>
 * list latency-link {
 *     key "timeStamp"
 *     leaf value {
 *         type decimal64;
 *     }
 *     leaf timeStamp {
 *         type int64;
 *     }
 * }
 * </pre>
 * The schema path to identify an instance is
 * <i>latency-link-model/latencies-link/latency-link</i>
 * <p>To create instances of this class use {@link org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.latencies.link.LatencyLinkBuilder}.
 * @see org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.latencies.link.LatencyLinkBuilder@see org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.latencies.link.LatencyLinkKey
 */
public interface LatencyLink
    extends
    ChildOf<LatenciesLink>,
    Augmentable<org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.latencies.link.LatencyLink>,
    Identifiable<LatencyLinkKey>
{



    public static final QName QNAME = org.opendaylight.yangtools.yang.common.QName.create("urn:opendaylight:latency-link-model","2014-06-06","latency-link");;

    BigDecimal getValue();
    
    java.lang.Long getTimeStamp();
    
    /**
     * Returns Primary Key of Yang List Type
     */
    LatencyLinkKey getKey();

}

