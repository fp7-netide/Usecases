/** Class LatencyLinkImpl created on 18 juil. 2014
* @author N. Kniebihli<br>
* DT/CEA/TAI Lab<br>
* Copyright (c) 2014 Thales Communications & Security<br>
* 4 av. des Louvresses - 92230 Gennevilliers - France<br>
* All rights reserved
*/
package org.opendaylight.controller.md.latencylink.consumer;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ExecutionException;

import org.opendaylight.controller.md.latencylink.GetException;
import org.opendaylight.controller.md.latencylink.InstanceIdentifierUtils;
import org.opendaylight.controller.md.sal.binding.api.DataBroker;
import org.opendaylight.controller.md.sal.common.api.data.LogicalDatastoreType;
import org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.Latencies;
import org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.latencies.link.LatencyLink;
import org.opendaylight.yang.gen.v1.urn.tbd.params.xml.ns.yang.network.topology.rev131021.network.topology.Topology;
import org.opendaylight.yang.gen.v1.urn.tbd.params.xml.ns.yang.network.topology.rev131021.network.topology.topology.Link;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Optional;

/**
 * @author template
 *
 */
public class LatencyLinkImpl implements ILatencyLink{

    private final DataBroker dataBroker;
    private final LogicalDatastoreType logicalDatastoreType;
    private final static Logger log = LoggerFactory.getLogger(LatencyLinkImpl.class);


    /**
     * Constructor
     * @param dataBroker
     */
    public LatencyLinkImpl(DataBroker dataBroker){
        log.info("LatencyLinkImpl Created");
        this.dataBroker = dataBroker;
        this.logicalDatastoreType = LogicalDatastoreType.OPERATIONAL;

    }
    /**
     * Sort
     * @param latencyLink
     */
    private static void sort(List<LatencyLink> latencyLink){
        Collections.sort(latencyLink, new Comparator<LatencyLink>() {
            @Override
            public int compare(LatencyLink o1,LatencyLink o2){
                return (int) (o2.getKey().getTimeStamp() - o1.getKey().getTimeStamp());
            }
        });
    }

    /**
     * Get All latency on the link
     * @param topologyId
     * @param linkId
     * @return Return Latencies object from MD-SAL
     * @throws GetException
     * @throws ExecutionException
     * @throws InterruptedException
     */

    @Override
    public Latencies getLatencies(String topologyId, String linkId) throws GetException, InterruptedException, ExecutionException{
        Optional<Latencies> res = this.dataBroker.newReadOnlyTransaction().read(
                logicalDatastoreType,
                InstanceIdentifierUtils.createPathLatencies(topologyId,linkId)).get();
        if(!res.isPresent()){
            throw new GetException();
        }
        Latencies out = res.get();
        sort(out.getLatencyLink());
        return out;
    }

    /**
     * Get the most recent latency on the link
     * @param topologyId
     * @param linkId
     * @return return Latency object from MD-SAL
     * @throws ExecutionException
     * @throws InterruptedException
     * @throws GetException
     */

    @Override
    public LatencyLink getLastLatency(String topologyId,String linkId) throws GetException, InterruptedException, ExecutionException {
        Latencies latencies = this.getLatencies(topologyId, linkId);
        return latencies.getLatencyLink().get(0);
    }

    /**
     * Get the most recent latency on all links
     * @param topologyId
     * @return Return a HashMap of linkId with Latency object from MD-SAL;
     * @throws ExecutionException
     * @throws InterruptedException
     * @throws GetException
     */

    @Override
    public HashMap<String,LatencyLink> getAllLastLatency(String topologyId) throws GetException, InterruptedException, ExecutionException {
        HashMap<String,LatencyLink> out = new HashMap<String,LatencyLink>();
        Optional<Topology> res = this.dataBroker.newReadOnlyTransaction().read(
                logicalDatastoreType,
                InstanceIdentifierUtils.generateTopologyInstanceIdentifier(topologyId)).get();
        if(!res.isPresent()){
            throw new GetException("getAllLastLatency");
        }

        ArrayList<Link> links = (ArrayList<Link>) res.get().getLink();
        for(Link link : links){
            out.put(link.getLinkId().getValue(), this.getLastLatency(topologyId, link.getLinkId().getValue()));
        }
        return out;
    }

    /**
     * Get All latencies on all links
     * @param topologyId
     * @return Return a HashMap of linkId with Latencies object from MD-SAL
     * @throws ExecutionException
     * @throws InterruptedException
     * @throws GetException
     */
    @Override
    public HashMap<String,Latencies> getAllLatencies(String topologyId) throws GetException, InterruptedException, ExecutionException {
        HashMap<String, Latencies> out = new HashMap<String,Latencies>();
        Optional<Topology> res = this.dataBroker.newReadOnlyTransaction().read(
                logicalDatastoreType,
                InstanceIdentifierUtils.generateTopologyInstanceIdentifier(topologyId)).get();
        if(!res.isPresent()){
            throw new GetException("getAllLatencies");
        }
        ArrayList<Link> links = (ArrayList<Link>) res.get().getLink();
        for(Link link : links){
            out.put(link.getLinkId().getValue(), this.getLatencies(topologyId, link.getLinkId().getValue()));
        }
        return out;
    }

}
