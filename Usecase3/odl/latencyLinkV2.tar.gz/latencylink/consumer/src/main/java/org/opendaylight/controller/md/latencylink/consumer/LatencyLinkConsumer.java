/** Class LatencyLinkConsumer created on 18 juil. 2014
* @author N. Kniebihli<br>
* DT/CEA/TAI Lab<br>
* Copyright (c) 2014 Thales Communications & Security<br>
* 4 av. des Louvresses - 92230 Gennevilliers - France<br>
* All rights reserved
*/
package org.opendaylight.controller.md.latencylink.consumer;

import org.opendaylight.controller.md.sal.binding.api.DataBroker;
import org.opendaylight.controller.sal.binding.api.AbstractBindingAwareConsumer;
import org.opendaylight.controller.sal.binding.api.BindingAwareBroker.ConsumerContext;
import org.opendaylight.controller.sal.utils.GlobalConstants;
import org.opendaylight.controller.sal.utils.ServiceHelper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author template
 *
 */
public class LatencyLinkConsumer extends AbstractBindingAwareConsumer implements AutoCloseable {

    private static final Logger log = LoggerFactory.getLogger(LatencyLinkConsumer.class);
    private LatencyLinkImpl latencyLinkImpl;


    @Override
    public void onSessionInitialized(ConsumerContext session) {
        log.info("LatencyLinkConsumer Started");

        DataBroker dataBroker = session.getSALService(DataBroker.class);

        this.latencyLinkImpl = new LatencyLinkImpl(dataBroker);
        //Register Interface in OSGI
        Boolean result = ServiceHelper.registerService(ILatencyLink.class, GlobalConstants.DEFAULT.toString(), this.latencyLinkImpl, null);
        log.debug("RegisterService is {}",result);
    }

    @Override
    public void close() throws Exception {
        log.info("LatencyLinkConsumer Close");
    }
}
