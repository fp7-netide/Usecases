/** Class ILatencyLink created on 18 juil. 2014
* @author N. Kniebihli<br>
* DT/CEA/TAI Lab<br>
* Copyright (c) 2014 Thales Communications & Security<br>
* 4 av. des Louvresses - 92230 Gennevilliers - France<br>
* All rights reserved
*/
package org.opendaylight.controller.md.latencylink.consumer;

import java.util.HashMap;
import java.util.concurrent.ExecutionException;

import org.opendaylight.controller.md.latencylink.GetException;
import org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.Latencies;
import org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.latencies.link.LatencyLink;


public interface ILatencyLink {

    /**
     * Get All latency on the link
     * @param topologyId
     * @param linkId
     * @return Return Latencies object from MD-SAL
     * @throws GetException
     * @throws ExecutionException
     * @throws InterruptedException
     */

    public Latencies getLatencies(String topologyId, String linkId) throws GetException, InterruptedException, ExecutionException;

    /**
     * Get the most recent latency on the link
     * @param topologyId
     * @param linkId
     * @return return Latency object from MD-SAL
     * @throws ExecutionException
     * @throws InterruptedException
     * @throws GetException
     */

    public LatencyLink getLastLatency(String topologyId,String linkId) throws GetException, InterruptedException, ExecutionException;

    /**
     * Get the most recent latency on all links
     * @param topologyId
     * @return Return a HashMap of linkId with Latency object from MD-SAL;
     * @throws ExecutionException
     * @throws InterruptedException
     * @throws GetException
     */

    public HashMap<String,LatencyLink> getAllLastLatency(String topologyId) throws GetException, InterruptedException, ExecutionException;

    /**
     * Get All latencies on all links
     * @param topologyId
     * @return Return a HashMap of linkId with Latencies object from MD-SAL
     * @throws ExecutionException
     * @throws InterruptedException
     * @throws GetException
     */
    public HashMap<String,Latencies> getAllLatencies(String topologyId) throws GetException, InterruptedException, ExecutionException;

}
