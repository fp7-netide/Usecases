#bin/bash
#Copier .jar de service et de model dans le dossier plugins de ODL Base dans integration
source couleur.sh

./exportModel.sh
if [ $? -eq 0 ] ;then
./exportService.sh
if [ $? -eq 0 ] ;then
./exportConsumer.sh
if [ $? -eq 0 ] ;then
./exportNorthBound.sh
if [ $? -eq 0 ] ;then
echo ""
echo -e  "${vertclair}[INFO]   BUILD OK   [INFO]${neutre}"
echo ""
fi
fi
fi
fi
