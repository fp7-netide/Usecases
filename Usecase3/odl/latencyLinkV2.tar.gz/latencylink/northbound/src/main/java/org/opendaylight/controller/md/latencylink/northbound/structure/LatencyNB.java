/** Class LatencyNb created on 21 juil. 2014
* @author N. Kniebihli<br>
* DT/CEA/TAI Lab<br>
* Copyright (c) 2014 Thales Communications & Security<br>
* 4 av. des Louvresses - 92230 Gennevilliers - France<br>
* All rights reserved
*/
package org.opendaylight.controller.md.latencylink.northbound.structure;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.latencies.link.LatencyLink;

@XmlRootElement
@XmlAccessorType(XmlAccessType.NONE)
public class LatencyNB {

    @XmlElement
    private long timeStamp;
    @XmlElement
    private double value;

    private LatencyNB(){}

   /**
    * Constructor of LatencyNB
    * @param latencyLink
    */
    public LatencyNB(LatencyLink latencyLink){
        this.timeStamp = latencyLink.getTimeStamp();
        this.value = latencyLink.getValue().doubleValue();
    }

    /** GETTER **/
    public double getTimestamp() {
        return this.timeStamp;
    }

    public double getValue() {
        return this.value;
    }
}
