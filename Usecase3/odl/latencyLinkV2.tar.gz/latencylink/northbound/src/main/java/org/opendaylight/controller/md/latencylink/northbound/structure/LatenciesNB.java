/** Class LatenciesNB created on 21 juil. 2014
* @author N. Kniebihli<br>
* DT/CEA/TAI Lab<br>
* Copyright (c) 2014 Thales Communications & Security<br>
* 4 av. des Louvresses - 92230 Gennevilliers - France<br>
* All rights reserved
*/
package org.opendaylight.controller.md.latencylink.northbound.structure;

import java.util.ArrayList;
import java.util.Iterator;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.Latencies;
import org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.latencies.link.LatencyLink;

@XmlRootElement
@XmlAccessorType(XmlAccessType.NONE)
public class LatenciesNB {

    @XmlElement
    String linkId;

    @XmlElement
    ArrayList<LatencyNB> latency;

    private LatenciesNB(){}

    /**
     * Constructor of LatenciesNB
     * @param latencies
     * @param linkId
     */
    public LatenciesNB(Latencies latencies,String linkId){
        this.latency = new ArrayList<LatencyNB>();
        Iterator<LatencyLink> iter = latencies.getLatencyLink().iterator();
        while(iter.hasNext()){
            this.latency.add(new LatencyNB(iter.next()));
        }
        this.linkId = linkId;
    }
}
