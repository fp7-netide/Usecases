/** Class LatencylinkNorthboundJAXRS created on 16 juil. 2014
* @author N. Kniebihli<br>
* DT/CEA/TAI Lab<br>
* Copyright (c) 2014 Thales Communications & Security<br>
* 4 av. des Louvresses - 92230 Gennevilliers - France<br>
* All rights reserved
*/
package org.opendaylight.controller.md.latencylink.northbound;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.ExecutionException;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.SecurityContext;
import javax.ws.rs.ext.ContextResolver;

import org.codehaus.enunciate.jaxrs.TypeHint;
import org.opendaylight.controller.md.latencylink.GetException;
import org.opendaylight.controller.md.latencylink.consumer.ILatencyLink;
import org.opendaylight.controller.md.latencylink.northbound.structure.AllLatenciesNB;
import org.opendaylight.controller.md.latencylink.northbound.structure.LatenciesNB;
import org.opendaylight.controller.northbound.commons.RestMessages;
import org.opendaylight.controller.northbound.commons.exception.ResourceNotFoundException;
import org.opendaylight.controller.northbound.commons.query.QueryContext;
import org.opendaylight.controller.sal.utils.ServiceHelper;
import org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.Latencies;
import org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.LatenciesBuilder;
import org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.latencies.link.LatencyLink;

/**
 * LatencyLink Northbound REST API
 *
 * <br>
 * <br>
 * Authentication scheme : <b>HTTP Basic</b><br>
 * Authentication realm : <b>opendaylight</b><br>
 * Transport : <b>HTTP and HTTPS</b><br>
 * <br>
 * HTTPS Authentication is disabled by default.
 */
@Path("/")
public class LatencylinkNorthboundJAXRS {

    private String username;
    private QueryContext queryContext;

    @Context
    public void setQueryContext(ContextResolver<QueryContext> queryCtxResolver) {
      if (queryCtxResolver != null) {
        queryContext = queryCtxResolver.getContext(QueryContext.class);
      }
    }
    @Context
    public void setSecurityContext(SecurityContext context) {
        if (context != null && context.getUserPrincipal() != null) {
            username = context.getUserPrincipal().getName();

        }
    }

    protected String getUserName() {
        return username;
    }

    /**
     * Get Latencies of specific link on specific topology
     * @param containerName
     * @param queryString
     * @param topologyId
     * @param linkId
     * @return
     */
    @Path("/{containerName}/latencies/{topologyId}/{linkId}")
    @GET
    @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    @TypeHint(LatenciesNB.class)
    public LatenciesNB getLatencies(@PathParam("containerName") String containerName,
            @QueryParam("_q") String queryString,
            @PathParam("topologyId") String topologyId,
            @PathParam("linkId") String linkId){
        ILatencyLink iLatencyLink = (ILatencyLink) ServiceHelper.getGlobalInstance(ILatencyLink.class, this);

        if (iLatencyLink == null) {
            throw new ResourceNotFoundException(RestMessages.NOCONTAINER.toString());
        }
        try {
            Latencies  latencies = iLatencyLink.getLatencies(topologyId, linkId);
            return new LatenciesNB(latencies, linkId);
        } catch (GetException | InterruptedException | ExecutionException e) {
            throw new ResourceNotFoundException(RestMessages.NORESOURCE.toString()+" Exception "+e.getMessage()+"\n");
        }
    }

    /**
     * Get Latencies of all links on specific topology
     * @param containerName
     * @param queryString
     * @param topologyId
     * @return
     */
    @Path("/{containerName}/latencies/{topologyId}")
    @GET
    @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    @TypeHint(AllLatenciesNB.class)

    public AllLatenciesNB getAllLatencies(@PathParam("containerName") String containerName,
            @QueryParam("_q") String queryString,
            @PathParam("topologyId") String topologyId){
        ILatencyLink iLatencyLink = (ILatencyLink) ServiceHelper.getGlobalInstance(ILatencyLink.class, this);

        if (iLatencyLink == null) {
            throw new ResourceNotFoundException(RestMessages.NOCONTAINER.toString()+ " iLatencyLink");
        }
        try {
            HashMap<String, Latencies>  latencies = iLatencyLink.getAllLatencies(topologyId);
            AllLatenciesNB allLatencies = new AllLatenciesNB(latencies);
            return allLatencies;
        } catch (GetException | InterruptedException | ExecutionException e) {
            e.printStackTrace();
            throw new ResourceNotFoundException(RestMessages.NORESOURCE.toString()+" Exception "+e.getMessage()+"\n");
        }
    }

    /**
     * Get LastLatency of specific link on specific topology
     * @param containerName
     * @param queryString
     * @param topologyId
     * @param linkId
     * @return
     */
    @Path("/{containerName}/lastLatency/{topologyId}/{linkId}")
    @GET
    @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    @TypeHint(LatenciesNB.class)
    public LatenciesNB getLastLatency(@PathParam("containerName") String containerName,
            @QueryParam("_q") String queryString,
            @PathParam("topologyId") String topologyId,
            @PathParam("linkId") String linkId){
        ILatencyLink iLatencyLink = (ILatencyLink) ServiceHelper.getGlobalInstance(ILatencyLink.class, this);

        if (iLatencyLink == null) {
            throw new ResourceNotFoundException(RestMessages.NOCONTAINER.toString());
        }
        try {
            LatencyLink  latencyLink = iLatencyLink.getLastLatency(topologyId, linkId);
            ArrayList<LatencyLink> listLatencyLink = new ArrayList<LatencyLink>();
            listLatencyLink.add(latencyLink);
            LatenciesBuilder latenciesBuild = new LatenciesBuilder();
            latenciesBuild.setLatencyLink(listLatencyLink);
            return new LatenciesNB(latenciesBuild.build(),linkId);
        } catch (GetException | InterruptedException | ExecutionException e) {
            throw new ResourceNotFoundException(RestMessages.NORESOURCE.toString()+" Exception "+e.getMessage()+"\n");
        }
    }

    /**
     * Get LastLatencies of all link on specific topology
     * @param containerName
     * @param queryString
     * @param topologyId
     * @return
     */
    @Path("/{containerName}/lastLatency/{topologyId}/")
    @GET
    @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    @TypeHint(AllLatenciesNB.class)
    public AllLatenciesNB getAllLastLatency(@PathParam("containerName") String containerName,
            @QueryParam("_q") String queryString,
            @PathParam("topologyId") String topologyId){
        ILatencyLink iLatencyLink = (ILatencyLink) ServiceHelper.getGlobalInstance(ILatencyLink.class, this);

        if (iLatencyLink == null) {
            throw new ResourceNotFoundException(RestMessages.NOCONTAINER.toString()+ " iLatencyLink");
        }
        try {
            HashMap<String, LatencyLink>  latencyLink = iLatencyLink.getAllLastLatency(topologyId);
            HashMap<String, Latencies> latencies = new HashMap<String, Latencies>();
            for(String linkId : latencyLink.keySet()){
                ArrayList<LatencyLink> listLatencyLink = new ArrayList<LatencyLink>();
                listLatencyLink.add(latencyLink.get(linkId));
                LatenciesBuilder latenciesBuild = new LatenciesBuilder();
                latenciesBuild.setLatencyLink(listLatencyLink);
                latencies.put(linkId, latenciesBuild.build());
            }
            AllLatenciesNB allLastLatency = new AllLatenciesNB(latencies);
            return allLastLatency;
        } catch (GetException | InterruptedException | ExecutionException e) {
            e.printStackTrace();
            throw new ResourceNotFoundException(RestMessages.NORESOURCE.toString()+" Exception "+e.getMessage()+"\n");
        }
    }
}
