                      /** Class LatencylinkProvider created on 1 juil. 2014
* @author N. Kniebihli<br>
* DT/CEA/TAI Lab<br>
* Copyright (c) 2014 Thales Communications & Security<br>
* 4 av. des Louvresses - 92230 Gennevilliers - France<br>
* All rights reserved
*/
package org.opendaylight.controller.md.latencylink;

import java.util.Timer;
import java.util.concurrent.TimeUnit;

import org.opendaylight.controller.md.latencylink._switch.LatencySwitchHandler;
import org.opendaylight.controller.md.latencylink._switch.LatencySwitchTracker;
import org.opendaylight.controller.md.latencylink.link.LatencyLinkTracker;
import org.opendaylight.controller.md.latencylink.link.PacketHandler;
import org.opendaylight.controller.md.sal.binding.api.DataBroker;
import org.opendaylight.controller.sal.binding.api.AbstractBindingAwareProvider;
import org.opendaylight.controller.sal.binding.api.BindingAwareBroker.ProviderContext;
import org.opendaylight.controller.sal.binding.api.NotificationProviderService;
import org.opendaylight.controller.sal.binding.api.data.DataBrokerService;
import org.opendaylight.yang.gen.v1.urn.opendaylight.meter.statistics.rev131111.OpendaylightMeterStatisticsService;
import org.opendaylight.yang.gen.v1.urn.opendaylight.packet.service.rev130709.PacketProcessingService;
import org.opendaylight.yangtools.concepts.Registration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class LatencylinkProvider extends AbstractBindingAwareProvider
                                    implements AutoCloseable {

    private static final Logger log = LoggerFactory.getLogger(LatencylinkProvider.class);

    //Constant
    private static final long TIMER_PERIOD = TimeUnit.SECONDS.toMillis(1);
    private static final long TIMER_DELAY_START = TimeUnit.SECONDS.toMillis(15);
    private static final int SIZE_MAX = 10;
    private static final int LATENCY_MEAN = 5;

    private Registration listenerRegistration;
    private Timer timer;

    private PacketHandler packetHandler;


    /**
     * Call by OSGI when the bundle is started
     */
    @SuppressWarnings("deprecation")
    @Override
    public void onSessionInitiated(ProviderContext session) {
        log.info("LatencyLinkProvider Started");
        //New API
        DataBroker dataBroker = session.getSALService(DataBroker.class);
        //OLD API
        DataBrokerService dataBrokerService = session.getSALService(DataBrokerService.class);

        //Call RPC service
        LatencyLinkTracker latencyLinkTracker = new LatencyLinkTracker(dataBroker,dataBrokerService,SIZE_MAX);
        LatencySwitchTracker latencySwitchTracker = new LatencySwitchTracker(dataBroker,dataBrokerService,SIZE_MAX);
        NotificationProviderService notificationService =
                session.<NotificationProviderService>getSALService(NotificationProviderService.class);
        PacketProcessingService packetProcessingService =
                session.<PacketProcessingService>getRpcService(PacketProcessingService.class);
        OpendaylightMeterStatisticsService meterStatisticsService =
                session.getRpcService(OpendaylightMeterStatisticsService.class);

        this.timer = new Timer();
        InventoryService inventoryService = new InventoryService(dataBroker);
        inventoryService.registerAsDataChangeListener();

        log.trace("PacketHandler created");
        this.packetHandler = new PacketHandler(timer,TIMER_DELAY_START,TIMER_PERIOD, LATENCY_MEAN);
        this.packetHandler.setPacketProcessingService(packetProcessingService);
        this.packetHandler.setInventoryService(inventoryService);
        this.packetHandler.setLatencyLinkTracker(latencyLinkTracker);
        this.packetHandler.setLatencySwitchTracker(latencySwitchTracker);
        log.trace("PacketHandler registered notification");
        this.listenerRegistration = notificationService.registerNotificationListener(this.packetHandler);

        log.trace("LatencySwitch created");
        LatencySwitchHandler latencySwitchHandler = new LatencySwitchHandler(timer, TIMER_DELAY_START, TIMER_PERIOD, LATENCY_MEAN);
        latencySwitchHandler.setInventoryService(inventoryService);
        latencySwitchHandler.setLatencySwitchTracker(latencySwitchTracker);
        latencySwitchHandler.setMeterStatisticsService(meterStatisticsService);
        log.trace("LatencySwitchHanfler registred notification");
        this.listenerRegistration = notificationService.registerNotificationListener(latencySwitchHandler);
    }

    /*
     * (non-Javadoc)
     * @see java.lang.AutoCloseable#close()
     */
    @Override
    public void close() throws Exception {
        if(this.listenerRegistration != null) {
            this.listenerRegistration.close();
            this.timer.cancel();

        }
    }
}
