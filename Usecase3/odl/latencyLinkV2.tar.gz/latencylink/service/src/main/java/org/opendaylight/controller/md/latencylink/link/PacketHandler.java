/** Class PacketHandler created on 1 juil. 2014
* @author N. Kniebihli<br>
* DT/CEA/TAI Lab<br>
* Copyright (c) 2014 Thales Communications & Security<br>
* 4 av. des Louvresses - 92230 Gennevilliers - France<br>
* All rights reserved
*/
package org.opendaylight.controller.md.latencylink.link;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ExecutionException;

import org.opendaylight.controller.md.latencylink.GetException;
import org.opendaylight.controller.md.latencylink.InstanceIdentifierUtils;
import org.opendaylight.controller.md.latencylink.InventoryService;
import org.opendaylight.controller.md.latencylink.LatencyLinkPacket;
import org.opendaylight.controller.md.latencylink._switch.LatencySwitchTracker;
import org.opendaylight.controller.sal.packet.Ethernet;
import org.opendaylight.controller.sal.packet.LinkEncap;
import org.opendaylight.controller.sal.packet.Packet;
import org.opendaylight.controller.sal.packet.PacketException;
import org.opendaylight.controller.sal.packet.RawPacket;
import org.opendaylight.controller.sal.utils.NetUtils;
import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.NodeConnectorId;
import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.NodeConnectorRef;
import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.NodeRef;
import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.node.NodeConnectorKey;
import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.nodes.Node;
import org.opendaylight.yang.gen.v1.urn.opendaylight.packet.service.rev130709.PacketProcessingListener;
import org.opendaylight.yang.gen.v1.urn.opendaylight.packet.service.rev130709.PacketProcessingService;
import org.opendaylight.yang.gen.v1.urn.opendaylight.packet.service.rev130709.PacketReceived;
import org.opendaylight.yang.gen.v1.urn.opendaylight.packet.service.rev130709.TransmitPacketInput;
import org.opendaylight.yang.gen.v1.urn.opendaylight.packet.service.rev130709.TransmitPacketInputBuilder;
import org.opendaylight.yang.gen.v1.urn.tbd.params.xml.ns.yang.network.topology.rev131021.network.topology.topology.Link;
import org.opendaylight.yangtools.yang.binding.InstanceIdentifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PacketHandler implements PacketProcessingListener {

    private final static  Logger log = LoggerFactory.getLogger(PacketHandler.class);

    protected static final short TYPE_LATENCY_LINK = 0x07C3;

    private InventoryService inventoryService;
    private PacketProcessingService packetProcessingService;
    private LatencyLinkTracker latencyLinkTracker;
    private LatencySwitchTracker latencySwitchTracker;

    private final long period;
    private final int latencyMean;
    private final HashMap<String,ArrayList<Double>> latencyLinkTemp;
    private final Timer timerRequests;
    private final Timer timerRequest;
    private final TimerTask task = new TimerTask(){
        @Override
        public void run(){
            //log.trace("Run task timer");
            latencyRequest();
        }
    };

    //-- Getter --//

    public InventoryService getInventoryService(){
        return this.inventoryService;
    }

    //-- Setter --//

    public void setInventoryService(InventoryService inventoryService) {
        this.inventoryService = inventoryService;
    }

    public void setPacketProcessingService(PacketProcessingService packetProcessingService) {
        this.packetProcessingService = packetProcessingService;
    }

    public void setLatencyLinkTracker(LatencyLinkTracker latencyLinkTracker) {
        this.latencyLinkTracker = latencyLinkTracker;
    }

    public void setLatencySwitchTracker(LatencySwitchTracker latencySwitchTracker) {
        this.latencySwitchTracker = latencySwitchTracker;
    }

    /**
     * Constructor of PacketHandler
     */
    public PacketHandler(Timer timer,Long delay,Long period,int latencyMean){
        //log.trace("Constructor PacketHandler");
        this.timerRequests = timer;
        this.timerRequest = new Timer();
        this.period = period;
        this.timerRequests.schedule(task, delay, period);
        this.latencyMean = latencyMean;
        this.latencyLinkTemp = new HashMap<String,ArrayList<Double>>();
    }

    /**
     * The handler function for all outcoming packets
     * @throws ExecutionException
     * @throws InterruptedException
     * @throws PacketException
     */
    private void latencyRequest() {
        //log.debug("Latency Link request");
        if(this.inventoryService == null){
            log.error("InventoryService is NULL");
        }
        //Get list of link
        ArrayList<Link> listLink;
        long step;
        listLink = this.inventoryService.getLinks();
        if(listLink.size() !=0){
            step = this.period / listLink.size();
        }else{
            step = 0;
        }
        //Start request for each link with a specific offset.
        int position = 0;
        for(Link link : listLink){
            TaskRequestLink taskRequest = new TaskRequestLink(this, link);
            this.timerRequest.schedule(taskRequest, step*position);
            position++;
        }
    }

    /**
     * The handler function for all incoming packets
     * @param packetReceived The incoming packet
     */
    @Override
    public void onPacketReceived(PacketReceived packetReceived){

        //Snapshot of time
        long timeR = System.currentTimeMillis();
        //log.trace("timeR : {}", timeR);
        //Filter packetReceived
        if(packetReceived == null) {
            return;
        }
        try{
            byte[] payload = packetReceived.getPayload();
            RawPacket rawPacket = new RawPacket(payload);
            NodeConnectorRef ingress = packetReceived.getIngress();
            Packet packet = decodeDataPacket(rawPacket);
            if(!(packet instanceof Ethernet)) {
                return;
            }
            //log.trace("Frame ethernet received from {}",ingress.getValue());
            short etherType = ((Ethernet) packet).getEtherType();
            if(!(etherType == TYPE_LATENCY_LINK)){
                return;
            }
            handleLatencyLinkPacket(((Ethernet)packet),ingress,timeR);

        }catch(Exception e){
            log.error("Failed to handle packet {}",packetReceived, e);
        }
    }

    /**
     * The handler function for LatencyLink packets.
     * @param packet  The incoming Ethernet packet.
     * @param ingress  The NodeConnector where the Ethernet packet came from.
     * @param timeR The timestamp when the incoming packet
     */
    private void handleLatencyLinkPacket(Ethernet frame, NodeConnectorRef ingress,long timeR) {
        //log.trace("Frame latencyLink received from {}",ingress);
        //log.trace("Frame : {}",frame);
        //log.trace("Frame rawPayload {}",frame.getRawPayload());
        //log.trace("frame payload: {}",frame.getPayload());
        LatencyLinkPacket latencyLinkPacket = new LatencyLinkPacket();
        latencyLinkPacket.setTimestampByte(frame.getRawPayload());
        //Not Deserializatio with Ethernet because the Ethernet class don't know this type

        //Get Link path
        HashMap<String, String> linkPath;
        try {
            linkPath = this.inventoryService.getLinkPath(ingress);
            //log.trace("LinkPath :  {}",linkPath);

            //Get latency controller<->switch
            double latencyE;
            double latencyR;
            try{
                latencyE =this.latencySwitchTracker.getLocalLastLatency(linkPath.get("EGRESSNODE"));
            }catch(NullPointerException e){
                //log.trace("latency between node and controller is empty");
                latencyE = 0;
            }
            try{
                latencyR =this.latencySwitchTracker.getLocalLastLatency(linkPath.get("INGRESSNODE"));
            }catch(NullPointerException e){
                //log.trace("latency between node and controller is empty");
                latencyR = 0;
            }
            //Get timestamp of Emission
            long timeE = latencyLinkPacket.getTimestamp();
            //Compute the result
            double latencyLink = timeR - timeE - (latencyE + latencyR);
            if(latencyLink <=0 ){
                latencyLink = 0;
            }
//            log.debug("Latency Switch : {} ms {} ms",latencyE,latencyR);
//            log.debug("Latency {} at {} ms {} ms",linkPath.get("LINK"),timeR, latencyLink);
            if(this.latencyLinkTemp.get(linkPath.get("LINK")) == null){
                this.latencyLinkTemp.put(linkPath.get("LINK"),new ArrayList<Double>());
            }
            if(this.latencyLinkTemp.get(linkPath.get("LINK")).size() < this.latencyMean){
                this.latencyLinkTemp.get(linkPath.get("LINK")).add(latencyLink);
            }
            if(this.latencyLinkTemp.get(linkPath.get("LINK")).size() == this.latencyMean){
                double sum = 0;
                for(double tmp : this.latencyLinkTemp.get(linkPath.get("LINK"))){
                    sum += tmp;
                }
                this.latencyLinkTemp.get(linkPath.get("LINK")).clear();
                double mean = sum/this.latencyMean;
//                log.trace("SAVE DATASTORE FOR {} : {} ms",linkPath.get("LINK"),mean);
                //call rpc store latency in MD-SAL
                this.latencyLinkTracker.addLatency(linkPath.get("TOPOLOGY"), linkPath.get("LINK"), mean, timeR);
            }
        } catch (GetException | InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
    }

    /**
     * Decodes an incoming packet.
     * @param raw  The raw packet to be decoded.
     * @return  The decoded form of the raw packet.
     */
    private Packet decodeDataPacket(RawPacket raw) {
      if(raw == null) {
        return null;
      }
      byte[] data = raw.getPacketData();
      if(data.length <= 0) {
        return null;
      }
      if(raw.getEncap().equals(LinkEncap.ETHERNET)) {
        Ethernet res = new Ethernet();
        try {
          res.deserialize(data, 0, data.length * NetUtils.NumBitsInAByte);
          //res.setRawPayload(raw.getPacketData());
        } catch(Exception e) {
          log.warn("Failed to decode packet: {}", e.getMessage());
        }
        return res;
      }
      return null;
    }

    /**
     * Sends the specified packet on the specified port.
     * @param payload  The payload to be sent.
     * @param ingress  The NodeConnector where the payload came from.
     * @param egress  The NodeConnector where the payload will go.
     */
    protected void sendPacketOut(byte[] payload, NodeConnectorRef ingress, NodeConnectorRef egress) {
        //log.debug("sendPacketOut {}",ingress.getValue());
        //log.debug("sendPacketOut {}",egress.getValue());
      if (ingress == null || egress == null)  return;
      InstanceIdentifier<Node> egressNodePath = InstanceIdentifierUtils.getNodePath(egress.getValue());
      TransmitPacketInput input = new TransmitPacketInputBuilder() //
          .setPayload(payload) //
          .setNode(new NodeRef(egressNodePath)) //
          .setEgress(egress) //
          .setIngress(ingress) //
          .build();
      //log.debug("sendPacketOut ingress {}",ingress.getValue());
      //log.debug("sendPacketOut egress  {}",egress.getValue());
      this.packetProcessingService.transmitPacket(input);
    }
}

class TaskRequestLink extends TimerTask {

    private final static Logger log = LoggerFactory.getLogger(TaskRequestLink.class);

    private final PacketHandler packetHandler;
    private final Link link;

    public TaskRequestLink(PacketHandler packetHandler,Link link){
        this.packetHandler = packetHandler;
        this.link = link;
    }

    @SuppressWarnings("static-access")
    @Override
    public void run(){

        NodeConnectorRef nodeConnectorSrcLink;
        NodeConnectorRef ingress;
        try {
            //NodeConnector on source node and src link
            nodeConnectorSrcLink = this.packetHandler.getInventoryService().getNodeConnectorRef(new NodeConnectorKey(new NodeConnectorId(link.getSource().getSourceTp().getValue())));
            //NodeConnector on source node connect with controller
//            log.info("NodeConnectorSrcLink {}",nodeConnectorSrcLink);
            if(nodeConnectorSrcLink == null){
                return;
            }
            ingress = this.packetHandler.getInventoryService().getControllerNodeConnector(nodeConnectorSrcLink);

            //Create Ethernet frame
            Ethernet frame = new Ethernet();
            byte[] destinationMACAddress = new byte[] {(byte) 0xff, (byte) 0xff, (byte) 0xff, (byte) 0xff, (byte) 0xff, (byte) 0xff};
            byte[] sourceMACAddress = new byte[] {(byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00};
            frame.setEtherType(this.packetHandler.TYPE_LATENCY_LINK);
            frame.setSourceMACAddress(sourceMACAddress);
            frame.setDestinationMACAddress(destinationMACAddress);
            //Create the LatencyLinkPacket
            LatencyLinkPacket latencyLinkPacket = new LatencyLinkPacket();
            latencyLinkPacket.setTimestamp(System.currentTimeMillis());
            //log.trace("LatencyLinkPacket : {}",latencyLinkPacket);
            frame.setPayload(latencyLinkPacket);
            //log.trace("Frame Header Send : {}",frame);
            //log.trace("Frame Payload Send : {}",frame.getPayload());
            //Serialize frame
            byte[] payload = frame.serialize();
            //log.trace("After  set : {}",payload);
            //Send Packet
            this.packetHandler.sendPacketOut(payload, ingress, nodeConnectorSrcLink);
        }catch(PacketException e){
            e.printStackTrace();
        }
    }
}