/** Class LatencyLinkTracker created on 1 juil. 2014
* @author N. Kniebihli<br>
* DT/CEA/TAI Lab<br>
* Copyright (c) 2014 Thales Communications & Security<br>
* 4 av. des Louvresses - 92230 Gennevilliers - France<br>
* All rights reserved
*/
package org.opendaylight.controller.md.latencylink.link;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.opendaylight.controller.md.latencylink.GetException;
import org.opendaylight.controller.md.latencylink.InstanceIdentifierUtils;
import org.opendaylight.controller.md.sal.binding.api.DataBroker;
import org.opendaylight.controller.md.sal.binding.api.WriteTransaction;
import org.opendaylight.controller.md.sal.common.api.TransactionStatus;
import org.opendaylight.controller.md.sal.common.api.data.LogicalDatastoreType;
import org.opendaylight.controller.sal.binding.api.data.DataBrokerService;
import org.opendaylight.controller.sal.binding.api.data.DataModificationTransaction;
import org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.Latencies;
import org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.latencies.link.LatencyLink;
import org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.latencies.link.LatencyLinkBuilder;
import org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.latencies.link.LatencyLinkKey;
import org.opendaylight.yangtools.yang.common.RpcResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Optional;

@SuppressWarnings("deprecation")
public class LatencyLinkTracker{

    //New API
    private final DataBroker dataBroker;
    //OLD API to add information in tree
    private final DataBrokerService dataBrokerService;
    private final int sizeMax;
    private boolean removeInProgress;
    private final static Logger log = LoggerFactory.getLogger(LatencyLinkTracker.class);
    private final LogicalDatastoreType logicalDatastoreType;

    /**
     * Contruct a LatencyLinkTracker with the specified inputs
     * @param dataService The DataBrokerService for the LatencyLinkTracker
     * @param sizeMax The limit of number latency history
     */
    public LatencyLinkTracker(DataBroker dataBroker,DataBrokerService dataBrokerService, int sizeMax) {
        log.info("LatencyLinkTracker started");
        this.dataBroker = dataBroker;
        this.logicalDatastoreType = LogicalDatastoreType.OPERATIONAL;
        this.sizeMax = sizeMax;
        this.dataBrokerService = dataBrokerService;
    }

    /**
     * Get All latency on the link
     * @param topologyId
     * @param linkId
     * @return Return Latencies object from MD-SAL
     * @throws GetException
     * @throws ExecutionException
     * @throws InterruptedException
     */

    public Latencies getLatencies(String topologyId, String linkId) throws GetException, InterruptedException, ExecutionException{
        Optional<Latencies> res = this.dataBroker.newReadOnlyTransaction().read(
                logicalDatastoreType,
                InstanceIdentifierUtils.createPathLatencies(topologyId,linkId)).get();
        if(!res.isPresent()){
            throw new GetException();
        }
        return res.get();
    }

    /**
     * Add new latency on specific link
     * @param topologyId
     * @param linkId Identifier of link
     * @param latency Value of latency in ms
     * @param timeStamp Timestamp of latency
     * @return Return the state of commit
     */
    public Future<RpcResult<TransactionStatus>> addLatency(String topologyId, String linkId, double latency, long timeStamp){

        if(topologyId == null || linkId == null || latency < 0 || timeStamp <= 0){
            return null;
        }
        //log.debug(topologyId);
        this.removeInProgress = false;
        while(getSize(topologyId, linkId) >= this.sizeMax){
            if(!this.removeInProgress){
                removeOldTimeStamp(topologyId, linkId);
            }
        }
        //Create Latency
        final LatencyLinkBuilder builder = new LatencyLinkBuilder();
        builder.setValue(BigDecimal.valueOf(latency));
        builder.setTimeStamp(timeStamp);
        builder.setKey(new LatencyLinkKey(timeStamp));
        DataModificationTransaction it = this.dataBrokerService.beginTransaction();
        it.putOperationalData(
                InstanceIdentifierUtils.createPathLatency(topologyId,linkId,timeStamp),
                builder.build());
        return it.commit();
    }

    /**
     * Remove a specific latency of specific link
     * @param topologyId Identifier topology
     * @param linkId Identifier of link
     * @param timeStamp
     * @return Return the state of commit
     */
    public Future<RpcResult<TransactionStatus>> removeLatency(String topologyId, String linkId, long timeStamp){
        if(topologyId == null || linkId == null || timeStamp <= 0) {
            return null;
        }
        WriteTransaction writeTransaction = this.dataBroker.newWriteOnlyTransaction();
        writeTransaction.delete(
                logicalDatastoreType,
                InstanceIdentifierUtils.createPathLatency(topologyId,linkId,timeStamp));
        return writeTransaction.commit();
    }

    /**
     * Get the number of latency in latencies.
     * @param topologyId Identifier of Topology
     * @param linkId Identifier of link
     * @return The number of latency
     * @throws ExecutionException
     * @throws InterruptedException
     * @throws GetException
     */
    private int getSize(String topologyId,String linkId) {
        Latencies latencies;
        try {
            latencies = this.getLatencies(topologyId, linkId);
            return latencies.getLatencyLink().size();

        } catch (GetException | InterruptedException | ExecutionException e) {
            return 0;
        }

    }

    /**
     * Find the older latency and call removeLatency
     * @param topologyId Identifier of topology
     * @param linkId Identifier of link
     */
    private void removeOldTimeStamp(String topologyId, String linkId){
        Latencies latencies;
        try {
            //log.debug("RemoveOldLatency");
            latencies = this.getLatencies(topologyId, linkId);
            sort(latencies.getLatencyLink());
            this.removeLatency(topologyId, linkId, latencies.getLatencyLink().get(latencies.getLatencyLink().size()-1).getTimeStamp());
            this.removeInProgress = true;

        } catch (GetException | InterruptedException | ExecutionException e) {}
    }

    private static void sort(List<LatencyLink> latencyLink){
        Collections.sort(latencyLink, new Comparator<LatencyLink>() {
            @Override
            public int compare(LatencyLink o1,LatencyLink o2){
                return (int) (o2.getKey().getTimeStamp() - o1.getKey().getTimeStamp());
            }
        });
    }
}
