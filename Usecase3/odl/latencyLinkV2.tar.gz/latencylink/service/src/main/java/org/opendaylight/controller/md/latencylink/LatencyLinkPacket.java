/** Class LatencyLinkPacket created on 1 juil. 2014
* @author N. Kniebihli<br>
* DT/CEA/TAI Lab<br>
* Copyright (c) 2014 Thales Communications & Security<br>
* 4 av. des Louvresses - 92230 Gennevilliers - France<br>
* All rights reserved
*/
package org.opendaylight.controller.md.latencylink;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;
import org.opendaylight.controller.sal.packet.BitBufferHelper;
import org.opendaylight.controller.sal.packet.Packet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LatencyLinkPacket extends Packet {

    private static final Logger log = LoggerFactory.getLogger(LatencyLinkPacket.class);

    private static final String TIMESTAMP = "TimeStamp";

    private static  final Map<String, Pair<Integer, Integer>> fieldCoordinates = new LinkedHashMap<String, Pair<Integer, Integer>>() {
        private static final long serialVersionUID = 1L;
        {
            put(TIMESTAMP, new ImmutablePair<Integer, Integer>(0,64));
        }
    };

    private final Map<String, byte[]> fieldValues;

    /*
     * Constructor of LatencyLinkPacket
     */
    public LatencyLinkPacket() {
        super();
        this.fieldValues = new HashMap<String, byte[]>();
        this.hdrFieldCoordMap = fieldCoordinates;
        this.hdrFieldsMap = this.fieldValues;
        //log.debug("LatencyLink Packet created");

    }

    /*
     * Constructor of LatencyLinkPacket
     */
    public LatencyLinkPacket(boolean writeAccess){
        super(writeAccess);
        this.fieldValues = new HashMap<String, byte[]>();
        this.hdrFieldCoordMap = fieldCoordinates;
        this.hdrFieldsMap = this.fieldValues;
        //log.debug("LatencyLink Packet created");

    }

    /*
     * Getter of Timestamp
     * @return Return the value of TimeStamp
     */
    public long getTimestamp() {
        return BitBufferHelper.getLong(this.fieldValues.get(TIMESTAMP));
    }

    /*
     * Setter of Timestamp
     * @param timestamp the value of timestamp
     */
    public LatencyLinkPacket setTimestamp(long timestamp){
        this.fieldValues.put(TIMESTAMP, BitBufferHelper.toByteArray(timestamp));
        return this;
    }

    /*
     * Setter of Timestamp
     * $@param timestampe the value of timestamp in byte
     */
    public LatencyLinkPacket setTimestampByte(byte[] timestamp) {
        this.fieldValues.put(TIMESTAMP, timestamp);
        return this;
    }
}

