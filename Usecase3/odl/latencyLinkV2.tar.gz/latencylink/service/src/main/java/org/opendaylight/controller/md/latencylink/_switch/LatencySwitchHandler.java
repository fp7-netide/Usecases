/** Class LatencySwitchHandler created on 1 juil. 2014
* @author N. Kniebihli<br>
* DT/CEA/TAI Lab<br>
* Copyright (c) 2014 Thales Communications & Security<br>
* 4 av. des Louvresses - 92230 Gennevilliers - France<br>
* All rights reserved
*/
package org.opendaylight.controller.md.latencylink._switch;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Timer;
import java.util.TimerTask;

import org.opendaylight.controller.md.latencylink.InventoryService;
import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.NodeRef;
import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.Nodes;
import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.nodes.Node;
import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.nodes.NodeKey;
import org.opendaylight.yang.gen.v1.urn.opendaylight.meter.statistics.rev131111.GetAllMeterConfigStatisticsInputBuilder;
import org.opendaylight.yang.gen.v1.urn.opendaylight.meter.statistics.rev131111.MeterConfigStatsUpdated;
import org.opendaylight.yang.gen.v1.urn.opendaylight.meter.statistics.rev131111.MeterFeaturesUpdated;
import org.opendaylight.yang.gen.v1.urn.opendaylight.meter.statistics.rev131111.MeterStatisticsUpdated;
import org.opendaylight.yang.gen.v1.urn.opendaylight.meter.statistics.rev131111.OpendaylightMeterStatisticsListener;
import org.opendaylight.yang.gen.v1.urn.opendaylight.meter.statistics.rev131111.OpendaylightMeterStatisticsService;
import org.opendaylight.yangtools.yang.binding.InstanceIdentifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class LatencySwitchHandler implements OpendaylightMeterStatisticsListener{

    private final static Logger log = LoggerFactory.getLogger(LatencySwitchHandler.class);

    private InventoryService inventoryService;
    private LatencySwitchTracker latencySwitchTracker;
    private final long period;
    private final Timer timerRequests;
    private final Timer timerRequest;
    private final TimerTask task = new TimerTask(){
        @Override
        public void run(){
                latencySwitchRequest();
        }
    };

    private OpendaylightMeterStatisticsService meterStatisticsService;

    private final HashMap<NodeKey,Long> timeStart;
    private final HashSet<NodeKey> waitRep;
    private final int latencyMean;
    private final HashMap<String,ArrayList<Double>> latencySwitchTemp;

    //--Getter--//
    protected HashMap<NodeKey,Long> getTimeStart(){
        return this.timeStart;
    }

    public HashSet<NodeKey> getWaitRep() {
        return this.waitRep;
    }

    public OpendaylightMeterStatisticsService getMeterStatisticsService() {
        return this.meterStatisticsService;
    };
    //--Setter--//
    public void setInventoryService(InventoryService inventoryService){
        this.inventoryService = inventoryService;
    }

    public void setLatencySwitchTracker(LatencySwitchTracker latencySwitchTracker) {
        this.latencySwitchTracker = latencySwitchTracker;
    }

    /**
     * @param meterStatisticsService
     */
    public void setMeterStatisticsService(
            OpendaylightMeterStatisticsService meterStatisticsService) {
        this.meterStatisticsService = meterStatisticsService;
    }

    /*
     * Constructor of LatencySwitchHandler
     * @param timer Timer
     * @param delay delay for start the task
     * @param period period for task
     */
    public LatencySwitchHandler(Timer timer,Long delay, Long period,int latencyMean){
        this.timerRequests = timer;
        this.timerRequest = new Timer();
        this.period = period;
        this.timerRequests.schedule(task, delay, period);
        this.timeStart = new HashMap<NodeKey, Long>();
        this.waitRep = new HashSet<NodeKey>();
        this.latencyMean = latencyMean;
        this.latencySwitchTemp = new HashMap<String,ArrayList<Double>>();
    }

    /**
     * The handler function for all echo_request
     */
    private void latencySwitchRequest() {
        //log.debug("latencySwitchResquest()");
        if(this.inventoryService == null){
            log.error("InventoryService is NULL");
        }
        //Get list of Node
        ArrayList<Node> nodes;
        long step;
        nodes = this.inventoryService.getNodes();
        if(nodes.size() != 0){
            step = this.period / nodes.size();
        }else{
            step = 0;
        }
        int position= 0;
        //Send req to all node
        for(Node node : nodes){
            TaskRequestSwitch taskRequest = new TaskRequestSwitch(this,node);
            this.timerRequest.schedule(taskRequest, step*position);
            position++;
       }
    }

    /**
     * Notification when a MeterConfigStats is received by controller.
     */
    @Override
    public void onMeterConfigStatsUpdated(MeterConfigStatsUpdated notification){
        long timeEnd = System.currentTimeMillis();
        if(notification == null){
            return;
        }
        //log.debug("onMeterConfigStatsUpdated");
        NodeKey nodeKey = new NodeKey(notification.getId());
        if(this.waitRep.contains(nodeKey)){
            this.waitRep.remove(nodeKey);
            double latencySwitch = (timeEnd - this.timeStart.get(nodeKey))/2.0;
            if(latencySwitch <=0){
                latencySwitch = 0;
            }
//            log.trace("Latency {} at {} ms {} ms",nodeKey.getId().getValue(),timeEnd,latencySwitch);

            if(this.latencySwitchTemp.get(nodeKey.getId().getValue()) == null){
                this.latencySwitchTemp.put(nodeKey.getId().getValue(), new ArrayList<Double>());
            }
            if(this.latencySwitchTemp.get(nodeKey.getId().getValue()).size() < this.latencyMean){
                this.latencySwitchTemp.get(nodeKey.getId().getValue()).add(latencySwitch);
            }
            if(this.latencySwitchTemp.get(nodeKey.getId().getValue()).size() == this.latencyMean){
                double sum = 0;
                for(double tmp : this.latencySwitchTemp.get(nodeKey.getId().getValue())){
                    sum += tmp;
                }
                this.latencySwitchTemp.get(nodeKey.getId().getValue()).clear();
                double mean = sum/this.latencyMean;
//                log.trace("SAVE DATASTORE    {} ms",mean);
                //call rpc store latency in MD-SAL
                String topologyId = this.inventoryService.getTopology();
                this.latencySwitchTracker.addLatency(topologyId, nodeKey.getId().getValue(), mean, timeEnd);
            }
            //local store in SwitchTracker of last switch latency
            this.latencySwitchTracker.addLocalLastLatency(nodeKey.getId().getValue(),latencySwitch);


        }
    }

    @Override
    public void onMeterFeaturesUpdated(MeterFeaturesUpdated notification){}

    @Override
    public void onMeterStatisticsUpdated(MeterStatisticsUpdated notification) {}

}

class TaskRequestSwitch extends TimerTask {

    private final static Logger log = LoggerFactory.getLogger(TaskRequestSwitch.class);

    private final LatencySwitchHandler latencySwitchHandler;
    private final Node node;

    public TaskRequestSwitch(LatencySwitchHandler latencySwitchHandler,Node node){
        this.latencySwitchHandler = latencySwitchHandler;
        this.node = node;
    }

    @Override
    public void run(){
        if(!node.getKey().getId().getValue().equals("controller-config")){
            //log.trace("TaskRequest node : {}",node.getId());
            GetAllMeterConfigStatisticsInputBuilder input = new GetAllMeterConfigStatisticsInputBuilder();
            InstanceIdentifier<Node> targetNodeIdentifier =
                    InstanceIdentifier.builder(Nodes.class)
                        .child(Node.class, new NodeKey(node.getId()))
                        .build();
            NodeRef nodeRef = new NodeRef(targetNodeIdentifier);
            input.setNode(nodeRef);

            //save time
            this.latencySwitchHandler.getTimeStart().put(node.getKey(), System.currentTimeMillis());
            this.latencySwitchHandler.getWaitRep().add(node.getKey());
            //Call RPC Function
            this.latencySwitchHandler.getMeterStatisticsService().getAllMeterConfigStatistics(input.build());
        }
    }
}

