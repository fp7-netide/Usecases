/** Class InventoryService created on 1 juil. 2014
* @author N. Kniebihli<br>
* DT/CEA/TAI Lab<br>
* Copyright (c) 2014 Thales Communications & Security<br>
* 4 av. des Louvresses - 92230 Gennevilliers - France<br>
* All rights reserved
*/
package org.opendaylight.controller.md.latencylink;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutionException;

import org.opendaylight.controller.md.sal.binding.api.DataBroker;
import org.opendaylight.controller.md.sal.binding.api.DataChangeListener;
import org.opendaylight.controller.md.sal.common.api.data.AsyncDataBroker;
import org.opendaylight.controller.md.sal.common.api.data.AsyncDataChangeEvent;
import org.opendaylight.controller.md.sal.common.api.data.LogicalDatastoreType;
import org.opendaylight.yang.gen.v1.urn.opendaylight.flow.inventory.rev130819.FlowCapableNodeConnector;
import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.NodeConnectorRef;
import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.Nodes;
import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.node.NodeConnector;
import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.node.NodeConnectorKey;
import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.nodes.Node;
import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.nodes.NodeKey;
import org.opendaylight.yang.gen.v1.urn.tbd.params.xml.ns.yang.network.topology.rev131021.NetworkTopology;
import org.opendaylight.yang.gen.v1.urn.tbd.params.xml.ns.yang.network.topology.rev131021.TopologyId;
import org.opendaylight.yang.gen.v1.urn.tbd.params.xml.ns.yang.network.topology.rev131021.network.topology.Topology;
import org.opendaylight.yang.gen.v1.urn.tbd.params.xml.ns.yang.network.topology.rev131021.network.topology.TopologyKey;
import org.opendaylight.yang.gen.v1.urn.tbd.params.xml.ns.yang.network.topology.rev131021.network.topology.topology.Link;
import org.opendaylight.yangtools.yang.binding.DataObject;
import org.opendaylight.yangtools.yang.binding.InstanceIdentifier;
import org.opendaylight.yangtools.yang.binding.InstanceIdentifier.PathArgument;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Optional;

public class InventoryService implements DataChangeListener{

    private final static Logger log = LoggerFactory.getLogger(InventoryService.class);

    private final DataBroker dataBroker;

 // Key: switchId, Value: NodeConnectorRef that corresponds to NC between controller & switch
    private final HashMap<String, NodeConnectorRef> controllerSwitchConnectors;


    //Local store
    ArrayList<Link> listLink;
    ArrayList<Node> listNode;
    //Configuration
    private final LogicalDatastoreType logicalDatastoreType;
    private final String defaultTopologyId;
    /*
     * Constructor of InventoryService
     */
    public InventoryService(DataBroker dataBroker) {
        log.info("InventoryService started");
        this.dataBroker = dataBroker;
        this.logicalDatastoreType = LogicalDatastoreType.OPERATIONAL;
        this.defaultTopologyId = "flow:1";
        this.controllerSwitchConnectors = new HashMap<String,NodeConnectorRef>();
        this.listLink = new ArrayList<Link>();
        this.listNode = new ArrayList<Node>();
    }

    /**
     * Get the list of link
     * @return Return an arraylist of link
     * @throws GetException
     */
    public ArrayList<Link> getLinks(){
        return this.listLink;
    }

    /**
     * Get the Controller NodeConnectors of the network, which are the NodeConnectors connected to controller.
     * @return  The list of controller node connectors.
     */
    public HashMap<String, NodeConnectorRef>  getControllerSwitchConnectors(){
      // External NodeConnectors = All - Internal
        Set<String> internalNodeConnectors = new HashSet<>();
      for (Link link : this.getLinks()) {
          internalNodeConnectors.add(link.getDestination().getDestTp().getValue());
          internalNodeConnectors.add(link.getSource().getSourceTp().getValue());
      }
      for(Node node : this.listNode){
//          log.warn("node {} : {}",node.getId().getValue(),node.getNodeConnector());
          for(NodeConnector nodeConnector : node.getNodeConnector()){
                if(!internalNodeConnectors.contains(nodeConnector.getId().getValue())){
                    NodeConnectorRef ncRef = new NodeConnectorRef(
                            InstanceIdentifier.builder(Nodes.class).child(Node.class,node.getKey()).child(NodeConnector.class,nodeConnector.getKey()).toInstance());
                    if(!(nodeConnector.getAugmentation(FlowCapableNodeConnector.class).getName().contains("-"))){
                        controllerSwitchConnectors.put(node.getId().getValue(),ncRef);
                    }
                }
            }
      }
      return controllerSwitchConnectors;
    }

    /**
     * Get the controller node connector of node connnector who has the same node
     * @return Return the controller node connector ref
     */
    public NodeConnectorRef getControllerNodeConnector(NodeConnectorRef nodeConnectorRef){
        NodeConnectorRef controllerSwitchNodeConnector = null;
        HashMap<String, NodeConnectorRef> controllerSwitchConnectors = this.getControllerSwitchConnectors();
//        log.trace("NodeConnectorRef : {}",nodeConnectorRef.getValue());
        InstanceIdentifier<Node> nodePath = InstanceIdentifierUtils.getNodePath(nodeConnectorRef.getValue());
//        log.trace("nodePath : {}",nodePath);
        if (nodePath != null) {
            NodeKey nodeKey = InstanceIdentifierUtils.getNodeKey(nodePath);
            //log.trace("nodeKey : {}",nodeKey);
            if (nodeKey != null) {
                //log.trace("controllerSwitchConnectors : {}",controllerSwitchConnectors.toString());
                controllerSwitchNodeConnector = controllerSwitchConnectors.get(nodeKey.getId().getValue());
            }
        }
        //log.trace("controllerSwitchNodeConnector : {}",controllerSwitchNodeConnector);
        return controllerSwitchNodeConnector;
    }

    /**
     * Get the node connector ref
     * @param nodeConnectorKey the key of node connector
     * @return Return the node connector ref with the nodeconnectorKey
     */
    public NodeConnectorRef getNodeConnectorRef(NodeConnectorKey nodeConnectorKey){
//        log.trace("nodeConnectorKey Before for : {}",nodeConnectorKey);

        for (Node node : this.listNode) {
            for (NodeConnector nodeConnector : node.getNodeConnector()) {
//                log.trace("nodeConnector : {}",nodeConnector.getKey());
                if(nodeConnector.getKey().getId().getValue().equals(new NodeConnectorKey(nodeConnectorKey).getId().getValue())){
                    return new NodeConnectorRef(InstanceIdentifier.builder(Nodes.class).child(Node.class,node.getKey()).child(NodeConnector.class,nodeConnector.getKey()).toInstance());
                }
            }
        }
        return null;
    }

    /*
     * Get the topologyId and linkId of specific nodeconnectorref
     * @param ingress NodeConnetorRef of src link
     * @return Return the topology ID and link Id
     */
    public HashMap<String,String> getLinkPath(NodeConnectorRef ingress) throws GetException, InterruptedException, ExecutionException {

//        log.trace("Links : {}",links);
//        log.trace("Ingress {}",ingress);
        InstanceIdentifier<NodeConnector> nodeConnectorPath = InstanceIdentifierUtils.getNodeConnectorPath(ingress.getValue());
//        log.trace("InstanceIdentifier {}",nodeConnectorPath);
        NodeConnectorKey nodeConnectorKey = InstanceIdentifierUtils.getNodeConnectorKey(nodeConnectorPath);
//        log.trace("NodeConnectorKey {}",nodeConnectorKey);
//        log.trace("NodeConnectorKey {}",nodeConnectorKey.getId().getValue());

        for(Link link : this.listLink){
            if(link.getDestination().getDestTp().getValue().equals(nodeConnectorKey.getId().getValue())){
//                log.trace("Link founds, NodeConnectorKey {}",nodeConnectorKey.getId().getValue());
                HashMap<String,String> mapInfo = new HashMap<String,String>();
                mapInfo.put("TOPOLOGY", this.defaultTopologyId);
                mapInfo.put("LINK", link.getLinkId().getValue());
                mapInfo.put("EGRESSNODE", link.getSource().getSourceNode().getValue());
                mapInfo.put("INGRESSNODE", link.getDestination().getDestNode().getValue());
                return mapInfo;
            }
        }
        return null;
    }

    /** Get nodes from DataStore
     * @return Return all nodes under control of ODL
     * @throws ExecutionException
     * @throws InterruptedException
     * @throws GetException
     */
    private Nodes getNodesDataStore() throws InterruptedException, ExecutionException, GetException {
        InstanceIdentifier.InstanceIdentifierBuilder<Nodes> nodesInsIdBuilder = InstanceIdentifier.<Nodes>builder(Nodes.class);
        Optional<Nodes> res = this.dataBroker.newReadOnlyTransaction().read(
                logicalDatastoreType,
                nodesInsIdBuilder.toInstance()).get();
        if(!res.isPresent()){
            throw new GetException();
        }
        return res.get();
    }

    /**Return the list of node.
     * @return List of node
     */
    public ArrayList<Node> getNodes() {
        return this.listNode;
    }

    public void registerAsDataChangeListener() {
        InstanceIdentifier<Link> linkIns = InstanceIdentifier.builder(NetworkTopology.class)
                .child(Topology.class,new TopologyKey(new TopologyId(this.defaultTopologyId))).child(Link.class).toInstance();
        InstanceIdentifier<Node> nodeIns = InstanceIdentifier.builder(Nodes.class)
                .child(Node.class).toInstance();
        this.dataBroker.registerDataChangeListener(this.logicalDatastoreType, linkIns, this, AsyncDataBroker.DataChangeScope.BASE);
        this.dataBroker.registerDataChangeListener(this.logicalDatastoreType, nodeIns, this, AsyncDataBroker.DataChangeScope.ONE);
     }

     /* (non-Javadoc)
      * @see org.opendaylight.controller.md.sal.binding.api.DataChangeListener#onDataChanged(org.opendaylight.controller.md.sal.common.api.data.AsyncDataChangeEvent)
      */
     @Override
     public void onDataChanged(AsyncDataChangeEvent<InstanceIdentifier<?>, DataObject> change) {
         if(change == null){
             log.info("In onDataChanged: No Processing done as AsyncDataChangeEvent is null");
         }
         Map<InstanceIdentifier<?>, DataObject> original = change.getOriginalData();
         Map<InstanceIdentifier<?>, DataObject> create = change.getCreatedData();
         Map<InstanceIdentifier<?>, DataObject> update = change.getUpdatedData();
         Set<InstanceIdentifier<?>> delete = change.getRemovedPaths();

//         log.trace("Start onDataChanged");
//Check the state of listNode

//         for(Node node : this.listNode){
//             log.warn("Node : {}",node.getId().getValue());
//             for(NodeConnector  nc : node.getNodeConnector()){
//                 log.info(" nc    :     {}",nc.getId().getValue());
//             }
//         }
         for(Iterator<InstanceIdentifier<?>> iter = create.keySet().iterator();iter.hasNext();){
             InstanceIdentifier<?> res = iter.next();
             if(create.get(res) instanceof Link){
                 addLink(create.get(res));
             }
             if(create.get(res) instanceof Node){
                 updateNode();
             }
         }
         for(Iterator<InstanceIdentifier<?>> iter = update.keySet().iterator();iter.hasNext();){
             InstanceIdentifier<?> res = iter.next();
             if(update.get(res) instanceof Link){
                 addLink(update.get(res));
             }
             if(update.get(res) instanceof Node){
                 updateNode();
             }
         }
         for(Iterator<InstanceIdentifier<?>> iter = delete.iterator();iter.hasNext();){
             InstanceIdentifier<?> res = iter.next();
             Iterator<PathArgument> iter2 = res.getPathArguments().iterator();
             PathArgument res2 = null;
             while(iter2.hasNext()){
                 res2 = iter2.next();
             }
             if(res2.getType().toString().equals(Link.class.toString())){
                 if(original.get(res) != null){
                     removeLink(original.get(res));
                 }
             }
             if(res2.getType().toString().equals(Node.class.toString())){
                 updateNode();
             }
         }
//         log.trace("End onDataChanged");
     }

    /**
     * Remove a specific Link if exists in the listLink
     * @param res2
     */
    private void removeLink(DataObject dataObject) {
        for(Iterator<Link> iter = this.listLink.iterator();iter.hasNext();){
            Link link = iter.next();
            if(link.getKey().getLinkId().getValue().equals(((Link)dataObject).getKey().getLinkId().getValue())){
                this.listLink.remove(link);
                return;
            }
         }
    }

    /**
     * Update Node if already exists so remove the old list and synchro new list with DataStore
     * @param dataObject
     */
    private void updateNode() {
        this.listNode.clear();
        try {
            this.listNode.addAll(this.getNodesDataStore().getNode());
        } catch (InterruptedException | ExecutionException | GetException e) {
            e.printStackTrace();
        }
    }

    /**
     * Add new Link if already exists so remove the old Link and add the new
     * @param dataObject
     */
    private void addLink(DataObject dataObject) {
        if(dataObject ==null){
            return;
        }
        removeLink(dataObject);
        this.listLink.add((Link)dataObject);
    }

    /**
     * @param value
     * @return
     */
    public String getTopology() {
        return this.defaultTopologyId;
    }

}
