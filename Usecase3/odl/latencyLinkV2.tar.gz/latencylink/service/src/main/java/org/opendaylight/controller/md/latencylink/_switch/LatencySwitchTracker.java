/** Class LatencySwitchTracker created on 1 juil. 2014
* @author N. Kniebihli<br>
* DT/CEA/TAI Lab<br>
* Copyright (c) 2014 Thales Communications & Security<br>
* 4 av. des Louvresses - 92230 Gennevilliers - France<br>
* All rights reserved
*/
package org.opendaylight.controller.md.latencylink._switch;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.opendaylight.controller.md.latencylink.GetException;
import org.opendaylight.controller.md.sal.binding.api.DataBroker;
import org.opendaylight.controller.md.sal.binding.api.WriteTransaction;
import org.opendaylight.controller.md.sal.common.api.TransactionStatus;
import org.opendaylight.controller.md.sal.common.api.data.LogicalDatastoreType;
import org.opendaylight.controller.sal.binding.api.data.DataBrokerService;
import org.opendaylight.controller.sal.binding.api.data.DataModificationTransaction;
import org.opendaylight.yang.gen.v1.urn.opendaylight.latency._switch.model.rev140606.LatenciesSwitch;
import org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.latencies.link.LatencyLink;
import org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.latencies.link.LatencyLinkBuilder;
import org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.latencies.link.LatencyLinkKey;
import org.opendaylight.yang.gen.v1.urn.tbd.params.xml.ns.yang.network.topology.rev131021.NetworkTopology;
import org.opendaylight.yang.gen.v1.urn.tbd.params.xml.ns.yang.network.topology.rev131021.NodeId;
import org.opendaylight.yang.gen.v1.urn.tbd.params.xml.ns.yang.network.topology.rev131021.TopologyId;
import org.opendaylight.yang.gen.v1.urn.tbd.params.xml.ns.yang.network.topology.rev131021.network.topology.Topology;
import org.opendaylight.yang.gen.v1.urn.tbd.params.xml.ns.yang.network.topology.rev131021.network.topology.TopologyKey;
import org.opendaylight.yang.gen.v1.urn.tbd.params.xml.ns.yang.network.topology.rev131021.network.topology.topology.Node;
import org.opendaylight.yang.gen.v1.urn.tbd.params.xml.ns.yang.network.topology.rev131021.network.topology.topology.NodeKey;
import org.opendaylight.yangtools.yang.binding.InstanceIdentifier;
import org.opendaylight.yangtools.yang.common.RpcResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Optional;

@SuppressWarnings("deprecation")
public class LatencySwitchTracker {

    //New API
    private final DataBroker dataBroker;
    //OLD API
    private final DataBrokerService dataBrokerService;
    private final LogicalDatastoreType logicalDatastoreType;

    private boolean removeInProgress;
    private final int sizeMax;
    private final HashMap<String,Double> localLatency;
    private final static Logger log = LoggerFactory.getLogger(LatencySwitchTracker.class);

    /*
     * contruct a LatencySwitchTracker with the specified inputs
     * @param dataService The DataBrokerService for the LatencyLinkTracker
     */
    public LatencySwitchTracker( DataBroker dataBroker,DataBrokerService dataBrokerService, int sizeMax) {
        log.info("LatencySwitchTracker started");
        this.dataBroker = dataBroker;
        this.sizeMax = sizeMax;
        this.logicalDatastoreType = LogicalDatastoreType.OPERATIONAL;
        this.dataBrokerService = dataBrokerService;
        this.localLatency = new HashMap<String,Double>();
    }

    /**
     * Get All latency between controller and this node
     * @param topologyId
     * @param nodeId
     * @return Return Latencies object from MD-SAL
     * @throws ExecutionException
     * @throws InterruptedException
     * @throws GetException
     */
    public LatenciesSwitch getLatencies(String topologyId, String nodeId) throws InterruptedException, ExecutionException, GetException{

        Optional<LatenciesSwitch> res = this.dataBroker.newReadOnlyTransaction().read(
                logicalDatastoreType,
                createPathLatenciesSwitch(topologyId,nodeId)).get();
        if(!res.isPresent()){
            throw new GetException("GetLatencies");
        }
        return res.get();
    }


    /**
     * Get the last latency on specific topology and node
     * @param topologyId
     * @param nodeId
     * @return Return the latency link
     * @throws InterruptedException
     * @throws ExecutionException
     * @throws GetException
     */
    public LatencyLink getLastLatency(String topologyId, String nodeId) throws InterruptedException, ExecutionException, GetException{
        LatenciesSwitch latenciesSwitch = this.getLatencies(topologyId, nodeId);
        return latenciesSwitch.getLatencyLink().get(0);
    }

    /**
     * Add new latency on specific topology,node
     * @param topologyId
     * @param nodeId
     * @param latencySwitch
     * @param timeStamp
     * @return return the result of transaction
     */
    public Future<RpcResult<TransactionStatus>> addLatency(String topologyId,String nodeId, double latencySwitch, long timeStamp){
        if(topologyId == null || nodeId == null || latencySwitch < 0 || timeStamp <= 0){
            return null;
        }
        //log.trace("GetSize : {}",getSize(topologyId,nodeId));
        //Delete oldest latency if size = max
        this.removeInProgress = false;
        while(getSize(topologyId, nodeId) >= this.sizeMax){
            if(!this.removeInProgress){
                removeOldTimeStamp(topologyId, nodeId);
            }
        }
        //Create Latency
        final LatencyLinkBuilder builder = new LatencyLinkBuilder();
        builder.setValue(BigDecimal.valueOf(latencySwitch));
        builder.setTimeStamp(timeStamp);
        builder.setKey(new LatencyLinkKey(timeStamp));
        DataModificationTransaction it = this.dataBrokerService.beginTransaction();
        it.putOperationalData(
                createPathLatencySwitch(topologyId,nodeId,timeStamp),
                builder.build());

        return it.commit();
    }

    /**
     * Remove a specific latencyon specific topology and node
     * @param topologyId
     * @param nodeId
     * @param timeStamp
     * @return Return the result of transaction
     */
    public Future<RpcResult<TransactionStatus>> removeLatency(String topologyId, String nodeId, long timeStamp){
        if(topologyId == null || nodeId == null || timeStamp <= 0) {
            return null;
        }
        WriteTransaction writeTransaction = this.dataBroker.newWriteOnlyTransaction();
        writeTransaction.delete(
                logicalDatastoreType,
                createPathLatencySwitch(topologyId,nodeId,timeStamp));
        return writeTransaction.commit();
    }

    /**
     * Get the number of history latency on specific topology and node
     * @param topologyId
     * @param nodeId
     * @return
     */
    private int getSize(String topologyId,String nodeId){
        LatenciesSwitch latenciesSwitch;
        try {
            latenciesSwitch = this.getLatencies(topologyId, nodeId);
        } catch (InterruptedException | ExecutionException | GetException e) {
            return 0;
        }
        return latenciesSwitch.getLatencyLink().size();
    }

    /**
     * remove the oldest latency on specific topology and node
     * @param topologyId
     * @param nodeId
     */
    private void removeOldTimeStamp(String topologyId, String nodeId){
        LatenciesSwitch latenciesSwitch;
        try {
            latenciesSwitch = this.getLatencies(topologyId, nodeId);
            sort(latenciesSwitch.getLatencyLink());
            this.removeLatency(topologyId, nodeId, latenciesSwitch.getLatencyLink().get(latenciesSwitch.getLatencyLink().size()-1).getTimeStamp());
            this.removeInProgress = true;

        } catch (InterruptedException | ExecutionException | GetException e) {}
    }

    private static void sort(List<LatencyLink> latencyLink){
        Collections.sort(latencyLink, new Comparator<LatencyLink>() {
            @Override
            public int compare(LatencyLink o1,LatencyLink o2){
                return (int) (o2.getKey().getTimeStamp() - o1.getKey().getTimeStamp());
            }
        });
    }

    /**
     * Create path for specific latency
     * @param topologyId
     * @param nodeId
     * @param timeStamp
     * @return
     */
    private InstanceIdentifier<LatencyLink> createPathLatencySwitch(String topologyId,String nodeId,long timeStamp){
        return InstanceIdentifier.builder(NetworkTopology.class)
                .child(Topology.class,new TopologyKey( new TopologyId(topologyId)))
                .child(Node.class,new NodeKey(new NodeId(nodeId)))
                .augmentation(LatenciesSwitch.class)
                .child(LatencyLink.class, new LatencyLinkKey(timeStamp))
                .toInstance();
    }

    /**
     * Create path for latencies on specific topology and node
     * @param topologyId
     * @param nodeId
     * @return
     */
    private InstanceIdentifier<LatenciesSwitch> createPathLatenciesSwitch(String topologyId, String nodeId) {
        return InstanceIdentifier.builder(NetworkTopology.class)
                .child(Topology.class,new TopologyKey( new TopologyId(topologyId)))
                .child(Node.class, new NodeKey(new NodeId(nodeId)))
                .augmentation(LatenciesSwitch.class)
                .toInstance();
    }

    /**
     * Store the last Latency
     * @param value Value is the name of node
     * @param latencySwitch LatencySwitch is the value of latency
     */
    public void addLocalLastLatency(String value, double latencySwitch) {
        this.localLatency.put(value,latencySwitch);
    }
    /**
     * Get the last Latency
     * @param value value is the name of node
     * @return The value of latency for a specific node
     */
    public double getLocalLastLatency(String value){
        return this.localLatency.get(value);
    }
}
