/** Class GetException created on 8 juil. 2014
* @author N. Kniebihli<br>
* DT/CEA/TAI Lab<br>
* Copyright (c) 2014 Thales Communications & Security<br>
* 4 av. des Louvresses - 92230 Gennevilliers - France<br>
* All rights reserved
*/
package org.opendaylight.controller.md.latencylink;

/**
 * @author template
 *
 */
public class GetException extends Exception{
    public GetException(){
        super();
    }

    public GetException(String s){
        super(s);
    }
}
