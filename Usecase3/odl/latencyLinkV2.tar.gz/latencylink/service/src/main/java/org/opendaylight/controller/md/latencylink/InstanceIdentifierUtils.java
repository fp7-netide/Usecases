/** Class InstanceIdentifierUtils created on 1 juil. 2014
* @author N. Kniebihli<br>
* DT/CEA/TAI Lab<br>
* Copyright (c) 2014 Thales Communications & Security<br>
* 4 av. des Louvresses - 92230 Gennevilliers - France<br>
* All rights reserved
*/
package org.opendaylight.controller.md.latencylink;

import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.NodeConnectorId;
import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.NodeConnectorRef;
import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.NodeId;
import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.Nodes;
import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.node.NodeConnector;
import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.node.NodeConnectorKey;
import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.nodes.Node;
import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.nodes.NodeKey;
import org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.Latencies;
import org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.latencies.link.LatencyLink;
import org.opendaylight.yang.gen.v1.urn.opendaylight.latency.link.model.rev140606.latencies.link.LatencyLinkKey;
import org.opendaylight.yang.gen.v1.urn.tbd.params.xml.ns.yang.network.topology.rev131021.LinkId;
import org.opendaylight.yang.gen.v1.urn.tbd.params.xml.ns.yang.network.topology.rev131021.NetworkTopology;
import org.opendaylight.yang.gen.v1.urn.tbd.params.xml.ns.yang.network.topology.rev131021.TopologyId;
import org.opendaylight.yang.gen.v1.urn.tbd.params.xml.ns.yang.network.topology.rev131021.network.topology.Topology;
import org.opendaylight.yang.gen.v1.urn.tbd.params.xml.ns.yang.network.topology.rev131021.network.topology.TopologyKey;
import org.opendaylight.yang.gen.v1.urn.tbd.params.xml.ns.yang.network.topology.rev131021.network.topology.topology.Link;
import org.opendaylight.yang.gen.v1.urn.tbd.params.xml.ns.yang.network.topology.rev131021.network.topology.topology.LinkKey;
import org.opendaylight.yangtools.yang.binding.InstanceIdentifier;

/* InstanceIdentifierUtils provides utility functions related to InstanceIdentifiers.
 */
public class InstanceIdentifierUtils {
    private InstanceIdentifierUtils() {
        throw new UnsupportedOperationException("Utility class should never be instantiated");
    }

    /**
     * Creates an Instance Identifier (path) for node with specified id
     *
     * @param nodeId
     * @return Return the path
     */
    public static final InstanceIdentifier<Node> createNodePath(final NodeId nodeId) {
        return InstanceIdentifier.builder(Nodes.class) //
                .child(Node.class, new NodeKey(nodeId)) //
                .build();
    }

    /**
     * Shorten's node child path to node path.
     *
     * @param nodeChild child of node, from which we want node path.
     * @return Return the path
     */
    public static final InstanceIdentifier<Node> getNodePath(final InstanceIdentifier<?> nodeChild) {
        return nodeChild.firstIdentifierOf(Node.class);
    }

    /**
     * Extracts NodeConnectorKey from node connector path.
     * @param nodeconnectorPath
     * @return Return the key of node connector
     */
    public static NodeConnectorKey getNodeConnectorKey(final InstanceIdentifier<?> nodeConnectorPath) {
        return nodeConnectorPath.firstKeyOf(NodeConnector.class, NodeConnectorKey.class);
    }

    /**
     * Extracts NodeKey from node path.
     * @param nodePath path of specific node
     * @return Return the key of node
     */
    public static NodeKey getNodeKey(final InstanceIdentifier<?> nodePath) {
        return nodePath.firstKeyOf(Node.class, NodeKey.class);
    }


    /**
     * Create the path for node connector
     * @param nodeIdValue Identifier of node
     * @param nodeConnectorIdValue Identifier of nodeConnector
     * @return Return the path of nodeConnector
     */
    public static final InstanceIdentifier<NodeConnector> createNodeConnectorIdentifier(final String nodeIdValue,
            final String nodeConnectorIdValue) {
        return createNodePath(new NodeId(nodeIdValue))
                .child(NodeConnector.class, new NodeConnectorKey(new NodeConnectorId(nodeConnectorIdValue)));
    }

    /**
     * Generate node path from NodeConnector
     * @param nodeConnectorRef
     * @return Return the node path
     */
    public static InstanceIdentifier<Node> generateNodeInstanceIdentifier(final NodeConnectorRef nodeConnectorRef) {
        return nodeConnectorRef.getValue().firstIdentifierOf(Node.class);
    }

    /**
     * Generate topology path from topology id
     * @param topologyId Identifier of topology
     * @return Return the topology path
     */
    public static InstanceIdentifier<Topology> generateTopologyInstanceIdentifier(final String topologyId) {
        return InstanceIdentifier.builder(NetworkTopology.class)
                .child(Topology.class, new TopologyKey(new TopologyId(topologyId)))
                .toInstance();
    }

    /**
     * Get the nodeConnector Path
     * @param nodeConnectorPath
     * @return Return the NodeConnector path
     */
    public static InstanceIdentifier<NodeConnector> getNodeConnectorPath(final InstanceIdentifier<?> nodeConnectorPath) {
        return nodeConnectorPath.firstIdentifierOf(NodeConnector.class);
    }

    /**
     * Generate the path of Link
     * @param topologyId identifier of topology
     * @param linkId Identifier of link
     * @return Return the path of the link
     */
    public static InstanceIdentifier<Link> generateLinkInstanceIdentifier(final String topologyId, final String linkId) {
        return InstanceIdentifier.builder(NetworkTopology.class)
                    .child(Topology.class,new TopologyKey( new TopologyId(topologyId)))
                    .child(Link.class,new LinkKey(new LinkId(linkId)))
                    .toInstance();
    }

    /**
     * Create the path of links
     * @param topologyId Identifier of topology
     * @return Return the path to get links object
     */
    public static InstanceIdentifier<Link> createPathLink(String topologyId) {
        return InstanceIdentifier.builder(NetworkTopology.class)
                .child(Topology.class,new TopologyKey(new TopologyId(topologyId)))
                .child(Link.class)
                .toInstance();
    }

    /**
     * Create the path of latency
     * @param topologyId Identifier of topology
     * @param linkId Identifier of link
     * @param timeStamp define a specific timestamp
     * @return Return the path to get a specific latency object
     */
    public static InstanceIdentifier<LatencyLink> createPathLatency(String topologyId,String linkId,long timeStamp){
        return InstanceIdentifier.builder(NetworkTopology.class)
                .child(Topology.class,new TopologyKey( new TopologyId(topologyId)))
                .child(Link.class,new LinkKey(new LinkId(linkId)))
                .augmentation(Latencies.class)
                .child(LatencyLink.class, new LatencyLinkKey(timeStamp))
                .toInstance();
    }

    /**
     * Create the path of Latencies
     * @param topologyId Identifier of topology
     * @param linkId Identifier of link
     * @return Return the path to ger a specific Latencies object
     */
    public static InstanceIdentifier<Latencies> createPathLatencies(String topologyId,String linkId){
        return InstanceIdentifier.builder(NetworkTopology.class)
                .child(Topology.class,new TopologyKey( new TopologyId(topologyId)))
                .child(Link.class,new LinkKey(new LinkId(linkId)))
                .augmentation(Latencies.class)
                .toInstance();
    }
}

